import { Storage } from "../common/storage.js";

async function loadStudent() {
  const user = JSON.parse(localStorage.getItem("currentUser"));
  if (!user) return;

  const [grades, attendances, classes, students] = await Promise.all([
    Storage.getGrades(),
    Storage.getAttendances(),
    Storage.getClasses(),
    Storage.getStudents(),
  ]);

  // Encontrar registro do aluno vinculado ao usuário logado
  const student = students.find((s) => s.userId === user.id);
  if (!student) {
    document.getElementById("class-card").innerHTML =
      "<p>Aluno não encontrado.</p>";
    return;
  }

  // Mapear turmas
  const classMap = Object.fromEntries(classes.map((c) => [c.id, c.name]));

  // Turma
  const classCard = document.getElementById("class-card");
  const myClass = classes.find((c) => c.id === student.classId);
  if (myClass) {
    classCard.innerHTML = `
      <div class="card-title">${myClass.name}</div>
      <div class="card-description">${
        myClass.description || "Sem descrição"
      }</div>
    `;
  } else {
    classCard.innerHTML = `<p>Você ainda não está em uma turma.</p>`;
  }

  // Minhas notas
  const myGrades = grades.filter((g) => g.studentId === student.id);
  const gradesTable = document.getElementById("grades-table");
  gradesTable.innerHTML = "";
  myGrades.forEach((g) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${classMap[g.classId] || "-"}</td>
      <td>${g.type}</td>
      <td>${Number(g.value).toFixed(2)}</td>
    `;
    gradesTable.appendChild(tr);
  });

  // Minha frequência
  const myAttendances = attendances.filter((a) => a.studentId === student.id);
  const attTable = document.getElementById("attendances-table");
  attTable.innerHTML = "";
  myAttendances.forEach((a) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${classMap[a.classId] || "-"}</td>
      <td>${a.date}</td>
      <td>${a.present ? "Presente" : "Falta"}</td>
    `;
    attTable.appendChild(tr);
  });
}

loadStudent();
