// teacher.js
const API = "http://localhost:3001";

function $id(id) {
  return document.getElementById(id);
}
function apiGet(path) {
  return fetch(`${API}/${path}`).then((r) => r.json());
}
function apiRequest(path, method = "GET", body = null) {
  return fetch(`${API}/${path}`, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
}

// Tabs
window.switchTab = function (btn) {
  document
    .querySelectorAll(".tab-btn")
    .forEach((b) => b.classList.remove("active"));
  document
    .querySelectorAll(".tab-content")
    .forEach((c) => c.classList.remove("active"));
  btn.classList.add("active");
  $id(btn.dataset.tab).classList.add("active");
};

// Modal
window.openModal = async function (type, data = null) {
  $id("modal").style.display = "flex";
  const title = data ? "Editar" : "Novo";
  $id("modal-title").textContent = `${title} ${type}`;
  const fields = $id("modal-fields");

  let classes = [],
    students = [];
  try {
    classes = await apiGet("classes");
  } catch {}
  try {
    students = await apiGet("students");
  } catch {}

  if (type === "grade") {
    fields.innerHTML = `
      <label>Aluno</label>
      <select name="studentId" required>
        ${students
          .map((s) => `<option value="${s.id}">${s.name}</option>`)
          .join("")}
      </select>
      <label>Classe</label>
      <select name="classId" required>
        ${classes
          .map((c) => `<option value="${c.id}">${c.name}</option>`)
          .join("")}
      </select>
      <label>Tipo</label>
      <input name="type" placeholder="Ex: Prova 1" required>
      <label>Valor (0-10)</label>
      <input type="number" name="value" min="0" max="10" step="0.01" required>
    `;
  } else if (type === "attendance") {
    fields.innerHTML = `
      <label>Aluno</label>
      <select name="studentId" required>
        ${students
          .map((s) => `<option value="${s.id}">${s.name}</option>`)
          .join("")}
      </select>
      <label>Classe</label>
      <select name="classId" required>
        ${classes
          .map((c) => `<option value="${c.id}">${c.name}</option>`)
          .join("")}
      </select>
      <label>Data</label>
      <input type="date" name="date" value="${
        new Date().toISOString().split("T")[0]
      }" required>
      <label>Presente?</label>
      <select name="present">
        <option value="true">Sim</option>
        <option value="false">Não</option>
      </select>
    `;
  }

  const oldForm = $id("modal-form");
  const newForm = oldForm.cloneNode(true);
  oldForm.parentNode.replaceChild(newForm, oldForm);

  newForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(newForm).entries());
    if (fd.present) fd.present = fd.present === "true";
    if (fd.studentId) fd.studentId = Number(fd.studentId);
    if (fd.classId) fd.classId = Number(fd.classId);
    if (fd.value) fd.value = Number(fd.value);

    const endpoint = type === "grade" ? "grades" : "attendances";
    const res = await apiRequest(endpoint, "POST", fd);
    if (!res.ok) {
      alert("Erro ao salvar");
      return;
    }
    closeModal();
    await loadAll();
  });
};

window.closeModal = function () {
  $id("modal").style.display = "none";
  $id("modal-fields").innerHTML = "";
};

// Load functions
async function loadAll() {
  const classes = await apiGet("classes");
  const students = await apiGet("students");
  const grades = await apiGet("grades");
  const attendances = await apiGet("attendances");

  // Criar mapas para lookup rápido
  const classMap = Object.fromEntries(classes.map((c) => [c.id, c.name]));
  const studentMap = Object.fromEntries(students.map((s) => [s.id, s.name]));

  // Turmas
  const grid = $id("classes-grid");
  grid.innerHTML = "";
  classes.forEach((c) => {
    const card = document.createElement("div");
    card.innerHTML = `<strong>${c.name}</strong><div>${
      c.description || ""
    }</div>`;
    grid.appendChild(card);
  });

  // Alunos
  const tbodyS = $id("students-table").querySelector("tbody");
  tbodyS.innerHTML = "";
  students.forEach((s) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${s.name}</td>
      <td>${s.email}</td>
      <td>${classMap[s.classId] || "-"}</td>
    `;
    tbodyS.appendChild(tr);
  });

  // Notas
  const tbodyG = $id("grades-table").querySelector("tbody");
  tbodyG.innerHTML = "";
  grades.forEach((g) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${studentMap[g.studentId] || g.studentId}</td>
      <td>${classMap[g.classId] || g.classId}</td>
      <td>${g.type}</td>
      <td>${Number(g.value).toFixed(2)}</td>
    `;
    tbodyG.appendChild(tr);
  });

  // Frequência
  const tbodyA = $id("attendances-table").querySelector("tbody");
  tbodyA.innerHTML = "";
  attendances.forEach((a) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${studentMap[a.studentId] || a.studentId}</td>
      <td>${classMap[a.classId] || a.classId}</td>
      <td>${a.date}</td>
      <td>${a.present ? "Sim" : "Não"}</td>
    `;
    tbodyA.appendChild(tr);
  });
}

loadAll();
