const API_URL = "http://localhost:3001";

export const Storage = {
  async getUsers() {
    const res = await fetch(`${API_URL}/users`);
    return await res.json();
  },

  async getClasses() {
    const res = await fetch(`${API_URL}/classes`);
    return await res.json();
  },

  async getTeachers() {
    const res = await fetch(`${API_URL}/teachers`);
    return await res.json();
  },

  async getStudents() {
    const res = await fetch(`${API_URL}/students`);
    return await res.json();
  },

  async getAttendances() {
    const res = await fetch(`${API_URL}/attendances`);
    return await res.json();
  },

  async getGrades() {
    const res = await fetch(`${API_URL}/grades`);
    return await res.json();
  },
};
