// admin.js (replace your existing file with this)
// IMPORTANT: this file expects your backend at http://localhost:3001
const API = "http://localhost:3001";

// Helpers
function $id(id) {
  return document.getElementById(id);
}
function apiGet(path) {
  return fetch(`${API}/${path}`).then((r) => r.json());
}
function apiRequest(path, method = "GET", body = null) {
  return fetch(`${API}/${path}`, {
    method,
    headers: body ? { "Content-Type": "application/json" } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
}

// Tabs
window.switchTab = function (btn) {
  document
    .querySelectorAll(".tab-btn")
    .forEach((b) => b.classList.remove("active"));
  document
    .querySelectorAll(".tab-content")
    .forEach((c) => c.classList.remove("active"));
  btn.classList.add("active");
  $id(`${btn.dataset.tab}-tab`).classList.add("active");
};

// Modal utilities
window.openModal = async function (type, data = null) {
  $id("modal").style.display = "flex";
  const title = data ? "Editar" : "Novo";
  $id("modal-title").textContent = `${title} ${type}`;
  const fields = $id("modal-fields");
  fields.innerHTML = `<p>Loading...</p>`;

  // fetch options safely (if fail -> empty arrays)
  let teachers = [],
    classes = [];
  try {
    teachers = await apiGet("teachers");
  } catch (err) {
    console.warn("Failed to load teachers", err);
  }
  try {
    classes = await apiGet("classes");
  } catch (err) {
    console.warn("Failed to load classes", err);
  }

  // build fields
  if (type === "class") {
    fields.innerHTML = `
      <label>Nome</label>
      <input name="name" placeholder="Nome" value="${
        data?.name || ""
      }" required>
      <label>Descrição</label>
      <input name="description" placeholder="Descrição" value="${
        data?.description || ""
      }">
      <label>Professor</label>
      <select name="teacherId">
        <option value="">-- selecione --</option>
        ${teachers
          .map(
            (t) =>
              `<option value="${t.id}" ${
                data?.teacherId == t.id ? "selected" : ""
              }>${t.name}</option>`
          )
          .join("")}
      </select>
    `;
  } else if (type === "teacher") {
    fields.innerHTML = `
      <label>Nome</label>
      <input name="name" placeholder="Nome" value="${
        data?.name || ""
      }" required>
      <label>Email</label>
      <input name="email" placeholder="Email" value="${
        data?.email || ""
      }" required>
    `;
  } else if (type === "student") {
    fields.innerHTML = `
      <label>Nome</label>
      <input name="name" placeholder="Nome" value="${
        data?.name || ""
      }" required>
      <label>Email</label>
      <input name="email" placeholder="Email" value="${
        data?.email || ""
      }" required>
      <label>Turma</label>
      <select name="classId">
        <option value="">-- selecione --</option>
        ${classes
          .map(
            (c) =>
              `<option value="${c.id}" ${
                data?.classId == c.id ? "selected" : ""
              }>${c.name}</option>`
          )
          .join("")}
      </select>
    `;
  } else {
    fields.innerHTML = `<p>Unknown type</p>`;
  }

  // attach submit handler reliably: replace form with clone to remove old handlers
  const oldForm = $id("modal-form");
  const newForm = oldForm.cloneNode(true);
  oldForm.parentNode.replaceChild(newForm, oldForm);

  newForm.addEventListener("submit", async function (e) {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(newForm).entries());

    // convert numeric IDs where needed
    if (fd.teacherId) fd.teacherId = Number(fd.teacherId);
    if (fd.classId) fd.classId = Number(fd.classId);

    // endpoint mapping
    const endpoint =
      type === "class"
        ? "classes"
        : type === "teacher"
        ? "teachers"
        : type === "student"
        ? "students"
        : `${type}s`;

    try {
      let res;
      if (data && data.id) {
        // EDIT
        res = await apiRequest(`${endpoint}/${data.id}`, "PUT", fd);
      } else {
        // CREATE
        res = await apiRequest(`${endpoint}`, "POST", fd);
      }

      if (!res.ok) {
        const text = await res.text().catch(() => null);
        console.error("Server error:", res.status, text);
        alert("Server returned an error. See console.");
        return;
      }

      // success
      closeModal();
      await loadAll();
    } catch (err) {
      console.error("Network error during save:", err);
      alert("Network error. See console.");
    }
  });
};

window.closeModal = function () {
  $id("modal").style.display = "none";
  $id("modal-fields").innerHTML = "";
};

// Load data and render
async function loadAll() {
  // classes
  let classes = [];
  try {
    classes = await apiGet("classes");
  } catch (err) {
    console.error("Failed to fetch classes", err);
  }

  const classesGrid = $id("classes-grid");
  classesGrid.innerHTML = "";
  for (const c of classes) {
    const card = document.createElement("div");
    card.className = "class-card";
    card.innerHTML = `
      <strong>${c.name}</strong>
      <div>${c.description || ""}</div>
      <div class="card-actions"></div>
    `;
    const actions = card.querySelector(".card-actions");
    const editBtn = document.createElement("button");
    editBtn.className = "btn primary";
    editBtn.textContent = "Editar";
    editBtn.addEventListener("click", () => openModal("class", c));
    const delBtn = document.createElement("button");
    delBtn.className = "btn danger";
    delBtn.textContent = "Excluir";
    delBtn.addEventListener("click", () => deleteItem("classes", c.id));
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    classesGrid.appendChild(card);
  }

  // teachers
  let teachers = [];
  try {
    teachers = await apiGet("teachers");
  } catch (err) {
    console.error("Failed to fetch teachers", err);
  }

  const teachersTbody = document.querySelector("#teachers-table tbody");
  teachersTbody.innerHTML = "";
  for (const t of teachers) {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${t.name}</td><td>${t.email}</td><td></td>`;
    const cell = tr.querySelector("td:last-child");
    const editBtn = document.createElement("button");
    editBtn.className = "btn primary";
    editBtn.textContent = "Editar";
    editBtn.addEventListener("click", () => openModal("teacher", t));
    const delBtn = document.createElement("button");
    delBtn.className = "btn danger";
    delBtn.textContent = "Excluir";
    delBtn.addEventListener("click", () => deleteItem("teachers", t.id));
    cell.appendChild(editBtn);
    cell.appendChild(delBtn);
    teachersTbody.appendChild(tr);
  }

  // students
  let students = [];
  try {
    students = await apiGet("students");
  } catch (err) {
    console.error("Failed to fetch students", err);
  }

  const studentsTbody = document.querySelector("#students-table tbody");
  studentsTbody.innerHTML = "";
  for (const s of students) {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${s.name}</td><td>${s.email}</td><td></td>`;
    const cell = tr.querySelector("td:last-child");
    const editBtn = document.createElement("button");
    editBtn.className = "btn primary";
    editBtn.textContent = "Editar";
    editBtn.addEventListener("click", () => openModal("student", s));
    const delBtn = document.createElement("button");
    delBtn.className = "btn danger";
    delBtn.textContent = "Excluir";
    delBtn.addEventListener("click", () => deleteItem("students", s.id));
    cell.appendChild(editBtn);
    cell.appendChild(delBtn);
    studentsTbody.appendChild(tr);
  }
}

window.deleteItem = async function (type, id) {
  if (!confirm("Deletar?")) return;
  try {
    const res = await apiRequest(`${type}/${id}`, "DELETE");
    if (!res.ok) {
      const t = await res.text().catch(() => null);
      console.error("Delete failed", res.status, t);
      alert("Delete failed. See console.");
      return;
    }
    await loadAll();
  } catch (err) {
    console.error("Network error on delete", err);
    alert("Network error. See console.");
  }
};

// initial load
loadAll();
