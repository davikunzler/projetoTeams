import express from "express";
import cors from "cors";
import { pool } from "./db.js";

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;

// ================== USERS ==================
app.get("/users", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM users");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================== LOGIN ==================
app.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    const [rows] = await pool.query(
      "SELECT * FROM users WHERE username=? AND password=?",
      [username, password]
    );
    if (rows.length > 0) res.json(rows[0]);
    else res.status(401).json({ message: "Usuário ou senha incorretos" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ================== TEACHERS ==================
app.get("/teachers", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM teachers");
  res.json(rows);
});

app.post("/teachers", async (req, res) => {
  const { name, email } = req.body;
  const [userResult] = await pool.query(
    "INSERT INTO users (username,password,name,role) VALUES (?,?,?,?)",
    [email.split("@")[0], "prof123", name, "teacher"]
  );
  const [teacherResult] = await pool.query(
    "INSERT INTO teachers (name,email,userId) VALUES (?,?,?)",
    [name, email, userResult.insertId]
  );
  res.json({ id: teacherResult.insertId, name, email });
});

app.put("/teachers/:id", async (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;
  await pool.query("UPDATE teachers SET name=?, email=? WHERE id=?", [
    name,
    email,
    id,
  ]);
  await pool.query(
    "UPDATE users SET name=?, username=? WHERE id=(SELECT userId FROM teachers WHERE id=?)",
    [name, email.split("@")[0], id]
  );
  res.json({ id, name, email });
});

app.delete("/teachers/:id", async (req, res) => {
  const { id } = req.params;
  await pool.query("DELETE FROM teachers WHERE id=?", [id]);
  res.json({ message: "Professor deletado" });
});

// ================== CLASSES ==================
app.get("/classes", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM classes");
  res.json(rows);
});

app.post("/classes", async (req, res) => {
  const { name, description, teacherId } = req.body;
  const [result] = await pool.query(
    "INSERT INTO classes (name, description, teacherId) VALUES (?,?,?)",
    [name, description, teacherId]
  );
  res.json({ id: result.insertId, name, description, teacherId });
});

app.put("/classes/:id", async (req, res) => {
  const { id } = req.params;
  const { name, description, teacherId } = req.body;
  await pool.query(
    "UPDATE classes SET name=?, description=?, teacherId=? WHERE id=?",
    [name, description, teacherId, id]
  );
  res.json({ id, name, description, teacherId });
});

app.delete("/classes/:id", async (req, res) => {
  const { id } = req.params;
  await pool.query("DELETE FROM classes WHERE id=?", [id]);
  res.json({ message: "Classe deletada" });
});

// ================== STUDENTS ==================
app.get("/students", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM students");
  res.json(rows);
});

app.post("/students", async (req, res) => {
  const { name, email, classId } = req.body;
  const [userResult] = await pool.query(
    "INSERT INTO users (username,password,name,role) VALUES (?,?,?,?)",
    [email.split("@")[0], "aluno123", name, "student"]
  );
  const [studentResult] = await pool.query(
    "INSERT INTO students (name,email,classId,userId) VALUES (?,?,?,?)",
    [name, email, classId, userResult.insertId]
  );
  res.json({ id: studentResult.insertId, name, email, classId });
});

app.put("/students/:id", async (req, res) => {
  const { id } = req.params;
  const { name, email, classId } = req.body;
  await pool.query(
    "UPDATE students SET name=?, email=?, classId=? WHERE id=?",
    [name, email, classId, id]
  );
  await pool.query(
    "UPDATE users SET name=?, username=? WHERE id=(SELECT userId FROM students WHERE id=?)",
    [name, email.split("@")[0], id]
  );
  res.json({ id, name, email, classId });
});

app.delete("/students/:id", async (req, res) => {
  const { id } = req.params;
  await pool.query("DELETE FROM students WHERE id=?", [id]);
  res.json({ message: "Aluno deletado" });
});

// ================== ATTENDANCES ==================
app.get("/attendances", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM attendances");
  res.json(rows);
});

app.post("/attendances", async (req, res) => {
  const { studentId, classId, date, present } = req.body;
  const [result] = await pool.query(
    "INSERT INTO attendances (studentId,classId,date,present) VALUES (?,?,?,?)",
    [studentId, classId, date, present]
  );
  res.json({ id: result.insertId, studentId, classId, date, present });
});

app.put("/attendances/:id", async (req, res) => {
  const { id } = req.params;
  const { present } = req.body;
  await pool.query("UPDATE attendances SET present=? WHERE id=?", [
    present,
    id,
  ]);
  res.json({ id, present });
});

// ================== GRADES ==================
app.get("/grades", async (req, res) => {
  const [rows] = await pool.query("SELECT * FROM grades");
  res.json(rows);
});

app.post("/grades", async (req, res) => {
  const { studentId, classId, type, value } = req.body;
  const [result] = await pool.query(
    "INSERT INTO grades (studentId,classId,type,value) VALUES (?,?,?,?)",
    [studentId, classId, type, value]
  );
  res.json({ id: result.insertId, studentId, classId, type, value });
});

app.put("/grades/:id", async (req, res) => {
  const { id } = req.params;
  const { value } = req.body;
  await pool.query("UPDATE grades SET value=? WHERE id=?", [value, id]);
  res.json({ id, value });
});

// ================== START SERVER ==================
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
